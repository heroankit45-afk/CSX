package com.megix

import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*

/** * Defines a provider and its execution logic for Standard, Anime, and MALSync data.
 * The `CineStreamExtractors.` receiver allows direct access to internal scraping functions.
 */
data class ProviderDef(
    val key: String,
    val displayName: String,
    val isTorrent: Boolean = false,
    val executeStandard: (suspend CineStreamExtractors.(res: AllLoadLinksData, subCb: (SubtitleFile) -> Unit, cb: (ExtractorLink) -> Unit) -> Unit)? = null,
    val executeAnime: (suspend CineStreamExtractors.(res: AllLoadLinksData, subCb: (SubtitleFile) -> Unit, cb: (ExtractorLink) -> Unit) -> Unit)? = null,
)

object ProviderRegistry {

    val builtInProviders = listOf(
        // ── Torrents ──────────────────────────────────────────────
        ProviderDef(
            key = "p_torrentio", displayName = "🧲 Torrentio", isTorrent = true,
            executeStandard = { res, _, cb -> invokeStremioTorrents("Torrentio", torrentioAPI, res.imdbId, res.season, res.episode, cb) },
            executeAnime = { res, _, cb -> invokeStremioTorrents("Torrentio", torrentioAPI, "kitsu:${res.kitsuId}", res.season, res.episode, cb) }
        ),
        ProviderDef(
            key = "p_torrentsdb", displayName = "🧲 TorrentsDB", isTorrent = true,
            executeStandard = { res, _, cb -> invokeStremioTorrents("TorrentsDB", torrentsdbAPI, res.imdbId, res.season, res.episode, cb) },
            executeAnime = { res, _, cb -> invokeStremioTorrents("TorrentsDB", torrentsdbAPI, "kitsu:${res.kitsuId}", res.season, res.episode, cb) }
        ),
        ProviderDef(
            key = "p_animetosho", displayName = "🧲 AnimeTosho", isTorrent = true,
            executeAnime = { res, _, cb -> invokeAnimetosho(res.kitsuId, res.malId, res.episode, cb) }
        ),

        // ── Stremio Addons & Subtitles ────────────────────────────
        ProviderDef(
            key = "p_wyziesubs", displayName = "WYZIESubs",
            executeStandard = { res, subCb, _ -> invokeWYZIESubs(res.imdbId, res.season, res.episode, subCb) },
            executeAnime = { res, subCb, _ -> invokeWYZIESubs(res.imdbId, res.imdbSeason, res.imdbEpisode, subCb) }
        ),
        ProviderDef(
            key = "p_stremiosubs", displayName = "StremioSubs",
            executeStandard = { res, subCb, _ -> invokeStremioSubtitles(res.imdbId, res.season, res.episode, subCb) },
            executeAnime = { res, subCb, _ -> invokeStremioSubtitles(res.imdbId, res.imdbSeason, res.imdbEpisode, subCb) }
        ),

        // ── Direct HTTP Providers ─────────────────────────────────
        ProviderDef(
            key = "p_showbox", displayName = "ShowBox",
            executeStandard = { res, subCb, cb -> invokeShowbox(res.imdbId, res.season, res.episode, subCb, cb) },
            executeAnime = { res, subCb, cb -> invokeShowbox(res.imdbId, res.imdbSeason, res.imdbEpisode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_vidrock", displayName = "Vidrock",
            executeStandard = { res, _, cb -> invokeVidrock(res.tmdbId, res.season, res.episode, cb) }
        ),
        ProviderDef(
            key = "p_moviebox", displayName = "Moviebox",
            executeStandard = { res, subCb, cb -> invokeMoviebox(res.title, res.season, res.episode, subCb, cb) },
            executeAnime = { res, subCb, cb -> invokeMoviebox(res.imdbTitle, res.imdbSeason, res.imdbEpisode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_movieblast", displayName = "MovieBlast",
            executeStandard = { res, subCb, cb -> invokeMovieBlast(res.title, res.season, res.episode, subCb, cb) },
        ),
        ProviderDef(
            key = "p_fibwatch", displayName = "Fibwatch",
            executeStandard = { res, subCb, cb -> invokeFibwatch(res.title, res.season, res.episode, subCb, cb) },
        ),
        ProviderDef(
            key = "p_allmovieland", displayName = "Allmovieland",
            executeStandard = { res, _, cb -> invokeAllmovieland(res.imdbId, res.season, res.episode, cb) },
        ),
        ProviderDef(
            key = "p_hdhub4u", displayName = "Hdhub4u",
            executeStandard = { res, subCb, cb -> invokeHdhub4u(res.imdbId, res.season, res.episode, subCb ,cb) },
        ),
        ProviderDef(
            key = "p_hexa", displayName = "Hexa",
            executeStandard = { res, _, cb -> invokeHexa(res.tmdbId, res.season, res.episode, cb) },
        ),
        ProviderDef(
            key = "p_fshare", displayName = "Fshare",
            executeStandard = { res, subCb, cb -> if (res.season == null) invokeFshare(res.title, res.imdbId, subCb, cb) }
        ),
        ProviderDef(
            key = "p_videasy", displayName = "Videasy",
            executeStandard = { res, subCb, cb -> invokeVideasy(res.title, res.tmdbId, res.imdbId, res.year, res.season, res.episode, subCb, cb) }
        ),
        // ProviderDef(
        //     key = "p_vidlink", displayName = "Vidlink",
        //     executeStandard = { res, subCb, cb -> invokeVidlink(res.tmdbId, res.season, res.episode, subCb, cb) },
        // ),
        ProviderDef(
            key = "p_vaplayer", displayName = "VaPlayer",
            executeStandard = { res, subCb, cb -> invokeVaPlayer(res.imdbId, res.season, res.episode, subCb, cb) },
            executeAnime = { res, subCb, cb -> invokeVaPlayer(res.imdbId, res.imdbSeason, res.imdbEpisode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_vidzee", displayName = "Vidzee",
            executeStandard = { res, subCb, cb -> invokeVidzee(res.tmdbId, res.season, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_peachify", displayName = "Peachify",
            executeStandard = { res, _, cb -> invokePeachify(res.tmdbId, res.season, res.episode, cb) }
        ),
        ProviderDef(
            key = "p_vidfastpro", displayName = "VidFastPro",
            executeStandard = { res, subCb, cb -> invokeVidFastPro(res.tmdbId, res.season, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_cinejoy", displayName = "Cinejoy",
            executeStandard = { res, subCb, cb -> invokeCinejoy(res.title, res.imdbId ,res.tmdbId, res.year ,res.season, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_vidcore", displayName = "Vidcore",
            executeStandard = { res, subCb, cb -> invokeVidcore(res.tmdbId, res.season, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_av1encodes", displayName = "Av1encodes",
            executeAnime = { res, _, cb -> invokeAv1encodes(res.imdbTitle, res.imdbSeason, res.imdbEpisode, cb) }
        ),
        ProviderDef(
            key = "p_castle", displayName = "Castle",
            executeStandard = { res, subCb, cb -> invokeCastle(res.title, res.season, res.episode, subCb, cb) },
            executeAnime = { res, subCb, cb -> invokeCastle(res.imdbTitle, res.imdbSeason, res.imdbEpisode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_reanime", displayName = "Reanime",
            executeAnime = { res, subCb, cb -> invokeReanime(res.anilistId, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_just4anime", displayName = "Just4Anime",
            executeAnime = { res, subCb, cb -> invokeJust4Anime(res.anilistId, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_zinkmovies", displayName = "Zinkmovies",
            executeStandard = { res, subCb, cb -> invokeZinkmovies(res.title, res.year, res.season, res.episode, subCb, cb) },
            executeAnime = { res, subCb, cb -> invokeZinkmovies(res.imdbTitle, res.imdbYear, res.imdbSeason, res.imdbEpisode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_bollywood", displayName = "Gramcinema",
            executeStandard = { res, _, cb -> invokeBollywood(res.title, res.year, res.season, res.episode, cb) },
            executeAnime = { res, _, cb -> invokeBollywood(res.imdbTitle, res.imdbYear, res.imdbSeason, res.imdbEpisode, cb) }
        ),
        ProviderDef(
            key = "p_vegamovies", displayName = "VegaMovies",
            executeStandard = { res, subCb, cb -> if (!res.isBollywood) invokeVegamovies("VegaMovies", res.imdbId, res.season, res.episode, subCb, cb) },
            executeAnime = { res, subCb, cb -> invokeVegamovies("VegaMovies", res.imdbId, res.imdbSeason, res.imdbEpisode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_rogmovies", displayName = "RogMovies",
            executeStandard = { res, subCb, cb -> if (res.isBollywood) invokeVegamovies("RogMovies", res.imdbId, res.season, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_bollyflix", displayName = "Bollyflix",
            executeStandard = { res, subCb, cb -> invokeBollyflix(res.imdbId, res.season, res.episode, subCb, cb) },
            executeAnime = { res, subCb, cb -> invokeBollyflix(res.imdbId, res.imdbSeason, res.imdbEpisode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_topmovies", displayName = "TopMovies",
            executeStandard = { res, subCb, cb -> if (res.isBollywood) invokeTopMovies(res.imdbId, res.season, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_vidup", displayName = "Vidup",
            executeStandard = { res, subCb, cb -> invokeVidup(res.tmdbId, res.season, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_meowtv", displayName = "Meowtv",
            executeStandard = { res, subCb, cb -> invokeMeowtv(res.tmdbId, res.season, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_moviesmod", displayName = "Moviesmod",
            executeStandard = { res, subCb, cb -> if (!res.isBollywood) invokeMoviesmod(res.imdbId, res.season, res.episode, subCb, cb) },
            executeAnime = { res, subCb, cb -> invokeMoviesmod(res.imdbId, res.imdbSeason, res.imdbEpisode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_movies4u", displayName = "Movies4u",
            executeStandard = { res, subCb, cb -> invokeMovies4u(res.imdbId, res.title, res.year, res.season, res.episode, subCb, cb) },
            executeAnime = { res, subCb, cb -> invokeMovies4u(res.imdbId, res.imdbTitle, res.imdbYear, res.imdbSeason, res.imdbEpisode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_dudefilms", displayName = "Dudefilms",
            executeStandard = { res, subCb, cb -> invokeDudefilms(res.imdbId, res.season, res.episode, subCb, cb) },
            executeAnime = { res, subCb, cb -> invokeDudefilms(res.imdbId, res.imdbSeason, res.imdbEpisode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_uhdmovies", displayName = "UHDMovies",
            executeStandard = { res, subCb, cb -> if (!res.isBollywood) invokeUhdmovies(res.title, res.year, res.season, res.episode, cb, subCb) },
            executeAnime = { res, subCb, cb -> invokeUhdmovies(res.imdbTitle, res.imdbYear, res.imdbSeason, res.imdbEpisode, cb, subCb) }
        ),
        ProviderDef(
            key = "p_moviesdrive", displayName = "MoviesDrive",
            executeStandard = { res, subCb, cb -> invokeMoviesdrive(res.title, res.imdbId, res.season, res.episode, subCb, cb) },
            executeAnime = { res, subCb, cb -> invokeMoviesdrive(res.imdbTitle, res.imdbId, res.imdbSeason, res.imdbEpisode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_hindmoviez", displayName = "Hindmoviez",
            executeStandard = { res, subCb, cb -> if (!res.isBollywood) invokeHindmoviez(res.imdbId, res.season, res.episode, subCb, cb) },
            executeAnime = { res, subCb, cb -> invokeHindmoviez(res.imdbId, res.imdbSeason, res.imdbEpisode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_4khdhub", displayName = "4KHDHub",
            executeStandard = { res, subCb, cb -> if (!res.isBollywood) invoke4khdhub(res.title, res.year, res.season, res.episode, subCb, cb) },
            executeAnime = { res, subCb, cb -> invoke4khdhub(res.imdbTitle, res.imdbYear, res.imdbSeason, res.imdbEpisode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_primesrc", displayName = "PrimeSrc",
            executeStandard = { res, subCb, cb -> invokePrimeSrc(res.imdbId, res.season, res.episode, subCb, cb) },
            executeAnime = { res, subCb, cb -> invokePrimeSrc(res.imdbId, res.imdbSeason, res.imdbEpisode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_projectfreetv", displayName = "ProjectFreeTV",
            executeStandard = { res, subCb, cb -> invokeProjectfreetv(res.title, res.airedYear ?: res.year, res.season, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_mlsbd", displayName = "Mlsbd",
            executeStandard = { res, subCb, cb -> invokeMlsbd(res.title, res.airedYear ?: res.year, res.season, subCb, cb) }
        ),
        ProviderDef(
            key = "p_levidia", displayName = "Levidia",
            executeStandard = { res, subCb, cb -> invokeLevidia(res.title, res.year, res.season, res.episode, subCb, cb) },
        ),
        ProviderDef(
            key = "p_animesalt", displayName = "Animesalt",
            executeStandard = { res, subCb, cb -> if (res.isAnime || res.isCartoon) invokeAnimesalt(res.title, res.season, res.episode, subCb, cb) },
            executeAnime = { res, subCb, cb -> invokeAnimesalt(res.imdbTitle, res.imdbSeason, res.imdbEpisode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_m4ufree", displayName = "M4ufree",
            executeStandard = { res, subCb, cb -> invokeM4ufree(res.title, res.year, res.season, res.episode, subCb, cb) },
        ),
        ProviderDef(
            key = "p_multimovies", displayName = "Multimovies",
            executeStandard = { res, subCb, cb -> invokeMultimovies(res.title, res.season, res.episode, subCb, cb) },
            executeAnime = { res, subCb, cb -> invokeMultimovies(res.imdbTitle, res.imdbSeason, res.imdbEpisode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_akwam", displayName = "Akwam",
            executeStandard = { res, subCb, cb -> invokeAkwam(res.imdbId, res.title, res.airedYear ?: res.year, res.season, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_rtally", displayName = "Rtally",
            executeStandard = { res, subCb, cb -> invokeRtally(res.title, res.season, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_asiaflix", displayName = "Asiaflix",
            executeStandard = { res, subCb, cb -> if (!res.isAnime) invokeAsiaflix(res.title, res.season, res.episode, res.airedYear ?: res.year, subCb, cb) }
        ),
        ProviderDef(
            key = "p_skymovies", displayName = "SkyMovies",
            executeStandard = { res, subCb, cb -> if (!res.isAnime) invokeSkymovies(res.title, res.airedYear ?: res.year, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_kisskh", displayName = "KissKH",
            executeStandard = { res, subCb, cb -> if (res.isAsian) invokeKisskh(res.title, res.year, res.season, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_onetouchtv", displayName = "Onetouchtv",
            executeStandard = { res, subCb, cb -> invokeOnetouchtv(res.title, res.airedYear ?: res.year, res.season, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_toonstream", displayName = "Toonstream",
            executeStandard = { res, subCb, cb -> if (res.isAnime || res.isCartoon) invokeToonstream(res.title, res.season, res.episode, subCb, cb) },
            executeAnime = { res, subCb, cb -> invokeToonstream(res.imdbTitle, res.imdbSeason, res.imdbEpisode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_anineko", displayName = "Anineko",
            executeAnime = { res, subCb, cb -> invokeAnineko(res.title, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_animedao", displayName = "Animedao",
            executeAnime = { res, subCb, cb -> invokeAnimedao(res.imdbTitle ,res.title, res.year, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_anikoto", displayName = "Anikoto",
            executeAnime = { res, subCb, cb -> invokeAnikoto(res.imdbTitle ?: res.title, res.year, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_anikage", displayName = "Anikage",
            executeAnime = { res, subCb, cb -> invokeAnikage(res.title, res.anilistId, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_anidb", displayName = "Anidb",
            executeAnime = { res, subCb, cb -> invokeAnidb(res.imdbTitle ?: res.title, res.year, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_animetoshohttp", displayName = "AnimeToshoHttp",
            executeAnime = { res, subCb, cb -> invokeAnimetoshoHttp(res.title, res.malId, res.episode, subCb, cb) }
        ),
        ProviderDef(
            key = "p_tokyoinsider", displayName = "TokyoInsider",
            executeAnime = { res, subCb, cb -> invokeTokyoInsider(res.originalTitle ?: res.title, res.episode, subCb, cb) },
        ),
        ProviderDef(
            key = "p_anizone", displayName = "Anizone",
            executeAnime = { res, subCb, cb -> invokeAnizone(res.originalTitle ?: res.title, res.episode, subCb, cb) },
        ),
        ProviderDef(
            key = "p_animekizz", displayName = "Animekizz",
            executeAnime = { res, subCb, cb -> invokeAnimekizz(res.title, res.anilistId, res.episode, subCb, cb) },
        ),
    )

    // Dynamically provided to Settings.kt
    val keys get() = builtInProviders.map { it.key }
    val namesMap get() = builtInProviders.associate { it.key to it.displayName }
    val torrentKeys get() = builtInProviders.filter { it.isTorrent }.map { it.key }.toSet()
}
